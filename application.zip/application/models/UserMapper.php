<?php

class Application_Model_UserMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_User();
    }

    public function addNewUser(Application_Model_User $user) {

        $unix_time = time();
        date_default_timezone_set("Asia/Calcutta");

        $userTable = new Application_Model_DbTable_User;
        $cols = $userTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "user_id",
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $column;exit;
                $data[$column] = $user->__get("$column");
            }
        }
        $result = $this->_db_table->insert($data);
        return($result);
    }

    public function getAllUsers() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'user_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $users_arr = array();
        foreach ($result as $row) {
            $user = new Application_Model_User($row);
            $users_arr[] = $user;
        }
        return $users_arr;
    }

    public function getUserById($id) {
        $where = array(
            "user_id = ?" => $id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            $user = new Application_Model_User();
            $user->user_fname = "--DELETED--";
            return FALSE;
        }
        $user = new Application_Model_User($result);
        return $user;
    }

    public function getUserByAgentId($id) {
        $where = array(
            "agent_id = ?" => $id
        );
        $result = $this->_db_table->fetchAll($where);
        if (count($result) == 0) {
            return false;
        }
        $users_arr = array();
        foreach ($result as $row) {
            $user = new Application_Model_User($row);
            $users_arr[] = $user;
        }

        return $users_arr;
    }

    public function updateUser(Application_Model_User $user) {


        $userTable = new Application_Model_DbTable_User;
        $cols = $userTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "user_id",
            "timestamp"
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $user->__get("$column") . "<br/>";
                $data[$column] = $user->__get("$column");
            }
        }

        $where = array(
            "user_id = ?" => $user->__get("user_id"),
        );
        $result = $this->_db_table->update($data, $where);

        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function deleteUserById($id) {
        $where = array(
            "id = ?" => $id
        );
        $result = $this->_db_table->delete($where);
        return $result;
    }

    public function getUsersByTaskId($task_id) {
        $where = array(
            "task_id = ?" => $task_id
        );
        $result = $this->_db_table->fetchRow($where, array(
            'id DESC'));

        if (!$result) {
            return FALSE;
        }
        $user = new Application_Model_User($result);
        return $user;
    }

    public function getUserByStoreIdAndConfigId($id, $store_id) {
        $where = array(
            "id = ?" => $id,
            "store_id = ?" => $store_id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {

            return FALSE;
        }
        $user = new Application_Model_User($result);
        return $user;
    }

    public function getRandomUsers() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'user_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $users_arr = array();
        foreach ($result as $row) {
            $user = new Application_Model_User($row);
            $users_arr[] = $user;
        }
        $recent_users_arr = array_slice($users_arr, 0, 8);

        return $recent_users_arr;
    }

    function generatePassword($numAlpha = 6, $numNonAlpha = 2) {
        $listAlpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $listNonAlpha = ',;:!?.$/*-+&@_+;./*&?$-!,';
        return str_shuffle(
                substr(str_shuffle($listAlpha), 0, $numAlpha) .
                substr(str_shuffle($listNonAlpha), 0, $numNonAlpha)
        );
    }

    public function checkUserApp($username,$password) {
        $where = array(
            "username = ?" => $username,
            "password = ?" => $password
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            $user = new Application_Model_User();
            $user->user_fname = "--DELETED--";
            return FALSE;
        }
        $user = new Application_Model_User($result);
        return $user;
    }
	
	public function getUserInfo($user_id){
		$select = $this->_db_table->select()
                ->from('user',array('*'))
                ->join('user_info','user.user_id=user_info.user_id',array('*'))
                ->where('user.user_id in('.implode(',',$user_id).')')
				->setIntegrityCheck(false);
		$result = $this->_db_table->fetchAll($select)->toArray();
        if (!$result) {
            return FALSE;
        }
        print_r($result);
        return $result;
	}
}
