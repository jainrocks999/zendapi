<?php

class Application_Model_StaticcontentMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Staticcontent();
    }

    public function getContent($page_name) {
        $where = array(
            "page_name = ?" => $page_name
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            return FALSE;
        }
        return $result->toArray();
    }

}
