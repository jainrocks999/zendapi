<?php

class Application_Model_UserchipsreqMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Userchipsreq();
    }
	
	public function sendRequest($user_id,$agent_id,$chips){
        $data = array(
                    'user_id'=>$user_id,
                    'agent_id'=>$agent_id,
                    'num_of_chips'=>$chips
                );
        $result = $this->_db_table->insert($data);
        return($result);
	}
}
