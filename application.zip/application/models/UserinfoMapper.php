<?php

class Application_Model_UserinfoMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Userinfo();
    }

    public function setUserToken($userid,$token) {
        $userTable = new Application_Model_DbTable_User;
		$data['token'] = $token;
        $where = array(
            "user_id = ?" => $userid
        );
        $result = $this->_db_table->update($data, $where);
        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function getUserToken($user_id) {
        $where = array(
            "user_id = ?" => $user_id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            $user = new Application_Model_User();
            $user->user_fname = "--DELETED--";
            return FALSE;
        }
        $user = new Application_Model_User($result);
        return $user;
    }

	public function updateUserinfo($data,$where) {
        $result = $this->_db_table->update($data, $where);

        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
	}

	 public function getUserinfo($user_id) {
        $where = array(
            "user_id = ?" => $user_id
        );
        $result = $this->_db_table->fetchRow($where);
        return $result;
    }
     public function score(){
        $select = $this->_db_table->select()
                ->from('user_info',array('score'))
                ->join('user','user.user_id=user_info.user_id',array('user_id','name'))
                ->order("score DESC")
                ->limit(20, 0)
                ->setIntegrityCheck(false);
        $result = $this->_db_table->fetchAll($select)->toArray();
        return $result;
    }


}
