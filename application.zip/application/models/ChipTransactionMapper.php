<?php

class Application_Model_ChipTransactionMapper{

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_ChipTransaction();
    }
public function insertchiptransaction($data,$where) {
        $result = $this->_db_table->insert($data, $where);

        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }
    public function transactionBet($user_id,$type,$numbers, $amount,$total_chips) {
        $data = array(
                    'user_id'=>$user_id,
                    'type'=>$type,
                    'numbers'=>$numbers,
                    'amount'=>$amount,
                    'total_amount'=>$total_chips
                );
        $result = $this->_db_table->insert($data);
        return($result);
    }

}
