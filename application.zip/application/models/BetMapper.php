<?php
class Application_Model_BetMapper {
	
    protected $_db_table;
    
	public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Bet();
    }
    
	public function addBet($user_id, $numbers, $amount) {
        $data = array(
                    'user_id'=>$user_id,
                    'numbers'=>$numbers,
                    'total_amount'=>$amount
                );
        $result = $this->_db_table->insert($data);
        return($result);
    }
	
	public function getUserinfo() {
         $select = $this->_db_table->select()
                ->from('bet',array('*'))
				->where('is_winner = 0');
               
        $result = $this->_db_table->fetchAll($select)->toArray();
        return $result;
    }

	public function getUserBetNumbers($user_id) {
         $select = $this->_db_table->select()
                ->from('bet',array('user_id','total_amount'))
				->where('is_winner = 0 and user_id!='.$user_id);
               
        $result = $this->_db_table->fetchAll($select)->toArray();
        return $result;
    }
    
	public function getBet($user_id,$bet_id) {
        $where = array(
                    'user_id = ?'=>$user_id,
                    'bet_id = ?'=>$bet_id
                );
        $result = $this->_db_table->fetchRow($where);
		if($result){
			return $result->toArray();
		}else{
			return false;
		}
    }
    
	public function deleteBet($user_id, $bet_id) {
        $where = array(
                    'bet_id = ?'=>$bet_id,
                    'is_winner = ?'=>'0'
                );
        $result = $this->_db_table->delete($where);
        return($result);
    }
	public function setWinner($winnernumber){
		$data = array(
            "winned_num_id" => $winnernumber,
			"is_winner"=>'1'
		);
        $where = array(
            "winned_num_id IS NULL" => '',
			"is_winner = ?"=>'0'
        );
        $result = $this->_db_table->update($data, $where);
		return $result;
	}

	public function getLastBet($user_id) {
         $select = $this->_db_table->select()
                ->from('bet',array('bet_id'))
				->where('is_winner = 0 and user_id='.$user_id)
                ->order("bet_id DESC")
                ->limit(1, 0);
               
        $result = $this->_db_table->fetchAll($select);
		if($result){
			return $result->toArray();
		}else{
			return false;
		}
    }
	public function getLastWinner(){
         $select = $this->_db_table->select()
                ->from('bet',array('winned_num_id'))
				->where('is_winner = 1')
                ->order("bet_id DESC")
                ->limit(1, 0);
               
        $result = $this->_db_table->fetchRow($select);
		if($result){
			return $result->toArray();
		}else{
			return false;
		}
	}

	public function getLastBetNumber($user_id) {
         $select = $this->_db_table->select()
                ->from('bet',array('numbers','total_amount as chips'))
				->where('is_winner = 0 and user_id='.$user_id)
                ->order("bet_id DESC");
               
        $result = $this->_db_table->fetchAll($select);
		if($result){
			return $result->toArray();
		}else{
			return false;
		}
    }
}
