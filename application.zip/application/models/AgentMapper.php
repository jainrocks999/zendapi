<?php

class Application_Model_AgentMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Agent();
    }

    public function addNewAgent(Application_Model_Agent $agent) {

        $unix_time = time();
        date_default_timezone_set("Asia/Calcutta");

        $agentTable = new Application_Model_DbTable_Agent;
        $cols = $agentTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "agent_id",
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $column;exit;
                $data[$column] = $agent->__get("$column");
            }
        }
        $result = $this->_db_table->insert($data);
        return($result);
    }

    public function getAllAgents() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'agent_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $agents_arr = array();
        foreach ($result as $row) {
            $agent = new Application_Model_Agent($row);
            $agents_arr[] = $agent;
        }
        return $agents_arr;
    }

    public function getAgentByDistributorId($id) {
        $where = array(
            "distributor_id = ?" => $id
        );
        $result = $this->_db_table->fetchAll($where);
       if (count($result) == 0) {
            return false;
        }
        $agents_arr = array();
        foreach ($result as $row) {
            $agent = new Application_Model_Agent($row);
            $agents_arr[] = $agent;
        }

        return $agents_arr;
    }
 public function getAgentById($id) {
        $where = array(
            "agent_id = ?" => $id
        );
        $result = $this->_db_table->fetchRow($where);
       if (count($result) == 0) {
            return false;
        }
       
            $agent = new Application_Model_Agent($result);
       
        

        return $agent;
    }
    public function getAgentByClientId($id) {
        $where = array(
            "client_id = ?" => $id
        );
        $result = $this->_db_table->fetchAll($where);
        if (count($result) == 0) {
            return false;
        }
        $agents_arr = array();
        foreach ($result as $row) {
            $agent = new Application_Model_Agent($row);
            $agents_arr[] = $agent;
        }

        return $agents_arr;
    }

    public function updateAgent(Application_Model_Agent $agent) {


        $agentTable = new Application_Model_DbTable_Agent;
        $cols = $agentTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "agent_id",
            "timestamp"
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $agent->__get("$column") . "<br/>";
                $data[$column] = $agent->__get("$column");
            }
        }

        $where = array(
            "agent_id = ?" => $agent->__get("agent_id"),
        );
        $result = $this->_db_table->update($data, $where);

        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function deleteAgentById($id) {
        $where = array(
            "id = ?" => $id
        );
        $result = $this->_db_table->delete($where);
        return $result;
    }

    public function getAgentsByTaskId($task_id) {
        $where = array(
            "task_id = ?" => $task_id
        );
        $result = $this->_db_table->fetchRow($where, array(
            'id DESC'));

        if (!$result) {
            return FALSE;
        }
        $agent = new Application_Model_Agent($result);
        return $agent;
    }

    public function getAgentByStoreIdAndConfigId($id, $store_id) {
        $where = array(
            "id = ?" => $id,
            "store_id = ?" => $store_id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {

            return FALSE;
        }
        $agent = new Application_Model_Agent($result);
        return $agent;
    }

    public function getRandomAgents() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'agent_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $agents_arr = array();
        foreach ($result as $row) {
            $agent = new Application_Model_Agent($row);
            $agents_arr[] = $agent;
        }
        $recent_agents_arr = array_slice($agents_arr, 0, 8);

        return $recent_agents_arr;
    }

    function generatePassword($numAlpha = 6, $numNonAlpha = 2) {
        $listAlpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $listNonAlpha = '!~)({}[]|#$';
        return str_shuffle(
                substr(str_shuffle($listAlpha), 0, $numAlpha) .
                substr(str_shuffle($listNonAlpha), 0, $numNonAlpha)
        );
    }

}
