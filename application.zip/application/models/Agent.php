<?php

class Application_Model_Agent {

    private $colum_array = array();

    public function __construct($row = NULL) {

        if (!is_null($row) && $row instanceof Zend_Db_Table_Row) {
            $cols = $row->getTable()->info(Zend_Db_Table_Abstract::COLS);
            foreach ($cols as $col) {
                $this->colum_array[$col] = $row->$col;
            }
        }
    }

    public function __set($name, $value) {
        $this->colum_array[$name] = $value;
    }

    public function __get($name) {
        return $this->colum_array[$name];
    }

}
