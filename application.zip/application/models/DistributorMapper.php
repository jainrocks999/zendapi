<?php

class Application_Model_DistributorMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Distributor();
    }

    public function addNewDistributor(Application_Model_Distributor $distributor) {

        $unix_time = time();
        date_default_timezone_set("Asia/Calcutta");

        $distributorTable = new Application_Model_DbTable_Distributor;
        $cols = $distributorTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "distributor_id",
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $column;exit;
                $data[$column] = $distributor->__get("$column");
            }
        }
        $result = $this->_db_table->insert($data);
        return($result);
    }

    public function getAllDistributors() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'distributor_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $distributors_arr = array();
        foreach ($result as $row) {
            $distributor = new Application_Model_Distributor($row);
            $distributors_arr[] = $distributor;
        }
        return $distributors_arr;
    }

    public function getDistributorById($id) {
        $where = array(
            "distributor_id = ?" => $id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            $distributor = new Application_Model_Distributor();
            $distributor->distributor_fname = "--DELETED--";
            return FALSE;
        }
        $distributor = new Application_Model_Distributor($result);
        return $distributor;
    }

    public function getDistributorByClientId($id) {
        $where = array(
            "client_id = ?" => $id
        );
        $result = $this->_db_table->fetchAll($where);
        if (count($result) == 0) {
            return false;
        }
        $distributors_arr = array();
        foreach ($result as $row) {
            $distributor = new Application_Model_Distributor($row);
            $distributors_arr[] = $distributor;
        }

        return $distributors_arr;
    }

    public function updateDistributor(Application_Model_Distributor $distributor) {


        $distributorTable = new Application_Model_DbTable_Distributor;
        $cols = $distributorTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "distributor_id",
            "timestamp"
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $distributor->__get("$column") . "<br/>";
                $data[$column] = $distributor->__get("$column");
            }
        }

        $where = array(
            "distributor_id = ?" => $distributor->__get("distributor_id"),
        );
        $result = $this->_db_table->update($data, $where);

        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function deleteDistributorById($id) {
        $where = array(
            "id = ?" => $id
        );
        $result = $this->_db_table->delete($where);
        return $result;
    }

    public function getDistributorsByTaskId($task_id) {
        $where = array(
            "task_id = ?" => $task_id
        );
        $result = $this->_db_table->fetchRow($where, array(
            'id DESC'));

        if (!$result) {
            return FALSE;
        }
        $distributor = new Application_Model_Distributor($result);
        return $distributor;
    }

    public function getDistributorByStoreIdAndConfigId($id, $store_id) {
        $where = array(
            "id = ?" => $id,
            "store_id = ?" => $store_id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {

            return FALSE;
        }
        $distributor = new Application_Model_Distributor($result);
        return $distributor;
    }

    public function getRandomDistributors() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'distributor_id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $distributors_arr = array();
        foreach ($result as $row) {
            $distributor = new Application_Model_Distributor($row);
            $distributors_arr[] = $distributor;
        }
        $recent_distributors_arr = array_slice($distributors_arr, 0, 8);

        return $recent_distributors_arr;
    }

    function generatePassword($numAlpha = 6, $numNonAlpha = 2) {
        $listAlpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $listNonAlpha = ',;:!?.$/*-+&@_+;./*&?$-!,';
        return str_shuffle(
                substr(str_shuffle($listAlpha), 0, $numAlpha) .
                substr(str_shuffle($listNonAlpha), 0, $numNonAlpha)
        );
    }

}
