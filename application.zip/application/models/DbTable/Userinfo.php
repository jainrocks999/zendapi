<?php

class Application_Model_DbTable_Userinfo extends Zend_Db_Table_Abstract{
    
    protected $_name="user_info";
}

