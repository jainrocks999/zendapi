<?php

class Application_Model_DbTable_Attributes extends Zend_Db_Table_Abstract{
    
    protected $_name="attribute";
}

