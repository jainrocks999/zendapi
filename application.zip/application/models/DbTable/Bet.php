<?php

class Application_Model_DbTable_Bet extends Zend_Db_Table_Abstract{
    
    protected $_name="bet";
}

