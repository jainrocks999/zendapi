<?php

class Application_Model_DbTable_Products extends Zend_Db_Table_Abstract{
    
    protected $_name="products";
}

