<?php

class Application_Model_DbTable_Admins extends Zend_Db_Table_Abstract{
    
    protected $_name="admin";
}

