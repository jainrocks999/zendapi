<?php

class Application_Model_DbTable_Configurations extends Zend_Db_Table_Abstract {

    protected $_name = "configuration";

}
