<?php

class Application_Model_DbTable_Userchipsreq extends Zend_Db_Table_Abstract{
    
    protected $_name="user_chips_requested";
}

