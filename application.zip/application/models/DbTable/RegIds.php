<?php

class Application_Model_DbTable_RegIds extends Zend_Db_Table_Abstract {

    protected $_name = "reg_ids";

}
