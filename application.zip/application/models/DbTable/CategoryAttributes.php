<?php

class Application_Model_DbTable_CategoryAttributes extends Zend_Db_Table_Abstract {

    protected $_name = "category_attribute_mapping";

}
