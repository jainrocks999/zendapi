<?php

class Application_Model_DbTable_ApiDocs extends Zend_Db_Table_Abstract {

    protected $_name = 'api_docs';

}
