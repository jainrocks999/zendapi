<?php

class Application_Model_DbTable_Orders extends Zend_Db_Table_Abstract {

    protected $_name = "order";

}
