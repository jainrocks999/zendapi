<?php

class Application_Model_DbTable_ProductImages extends Zend_Db_Table_Abstract {

    protected $_name = "product_image";

}
