<?php

class Application_Model_ApiDocsMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_ApiDocs();
    }

    public function addNewApi(Application_Model_ApiDocs $api) {
        $data = array(
            "api_url" => $api->__get("api_url"),
            "requestType" => $api->__get("requestType"),
            "params" => $api->__get("params"),
            "desc" => $api->__get("desc"),
            "response" => $api->__get("response")
        );
        $result = $this->_db_table->insert($data);
        return $result;
    }

    public function getAllApis() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'Api_doc_id DESC'));
        if (count($result) == 0)
        {
            return FALSE;
        }
        $api_arr = array();
        foreach ($result as $row)
        {
            $api = new Application_Model_ApiDocs($row);
            $api_arr[] = $api;
        }
        return $api_arr;
    }

    public function getApiById($id) {
        $where = array(
            "api_doc_id=?" => $id
        );
        $result = $this->_db_table->fetchRow($where);
        if (count($result) == 0)
        {
            return FALSE;
        }
        $api = new Application_Model_ApiDocs($result);
        return $api;
    }

    public function updateApi(Application_Model_ApiDocs $api) {
        $data = array(
            "api_url" => $api->__get("api_url"),
            "requestType" => $api->__get("requestType"),
            "params" => $api->__get("params"),
            "desc" => $api->__get("desc"),
            "response" => $api->__get("response")
        );
        $where = array(
            "api_doc_id=?" => $api->__get("api_doc_id")
        );
        $result = $this->_db_table->update($data, $where);
        if (count($result) == 0)
        {
            return FALSE;
        }
        return TRUE;
    }

    public function deleteApiById($id) {
        $where = array(
            "api_doc_id=?" => $id
        );
        $result = $this->_db_table->delete($where);
        return $result;
    }

}
