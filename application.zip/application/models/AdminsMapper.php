<?php

class Application_Model_AdminsMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Admins();
    }

    public function addNewAdmin(Application_Model_Admins $admin) {

        $unix_time = time();
        date_default_timezone_set("Asia/Calcutta");

        $adminTable = new Application_Model_DbTable_Admins;
        $cols = $adminTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "id",
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $column;exit;
                $data[$column] = $admin->__get("$column");
            }
        }
        $result = $this->_db_table->insert($data);
        return($result);
    }

    public function getAllAdmins() {
        $result = $this->_db_table->fetchAll(NULL, array(
            'id DESC'));
        if (count($result) == 0) {
            return false;
        }
        $admins_arr = array();
        foreach ($result as $row) {
            $admin = new Application_Model_Admins($row);
            $admins_arr[] = $admin;
        }
        return $admins_arr;
    }

    public function getAdminById($id) {
        $where = array(
            "id = ?" => $id
        );
        $result = $this->_db_table->fetchRow($where);
        if (!$result) {
            $admin = new Application_Model_Admins();
            $admin->admin_fname = "--DELETED--";
            return FALSE;
        }
        $admin = new Application_Model_Admins($result);
        return $admin;
    }

    public function updateAdmin(Application_Model_Admins $admin) {


        $adminTable = new Application_Model_DbTable_Admins;
        $cols = $adminTable->info(Zend_Db_Table::COLS);

        $not_acceptable_values = array(
            "id",
        );
        foreach ($not_acceptable_values as $col_not_want) {
            if (($key = array_search($col_not_want, $cols)) !== FALSE) {
                unset($cols[$key]); // remove the column that i dont want in array while inserting data in db like primary key timestamp etc
            }
        }
        if ($cols) {
            $data = array();
            foreach ($cols as $column) {
                //echo $admin->__get("$column") . "<br/>";
                $data[$column] = $admin->__get("$column");
            }
        }

        $where = array(
            "id = ?" => $admin->__get("id"),
        );
        $result = $this->_db_table->update($data, $where);
  
        if (count($result) == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function deleteAdminById($id) {
        $where = array(
            "id = ?" => $id
        );
        $result = $this->_db_table->delete($where);
        return $result;
    }


}
