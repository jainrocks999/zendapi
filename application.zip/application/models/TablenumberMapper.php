<?php

class Application_Model_TablenumberMapper {

    protected $_db_table;

    public function __construct() {
        $this->_db_table = new Application_Model_DbTable_Tablenumber();
    }

    public function getContent() {
        $result = $this->_db_table->fetchAll();
        if (!$result) {
            return FALSE;
        }
        return $result->toArray();
    }
	
    public function updateNumber($winnernumber,$total_win) {
		$where = array('number = ?'=>$winnernumber);
        $number = $this->_db_table->fetchRow($where);

		$data = array( "win" => $number['win']+$total_win );

        $result = $this->_db_table->update($data, $where);
        if (!$result) {
            return FALSE;
        }
        return $result;
    }

}
