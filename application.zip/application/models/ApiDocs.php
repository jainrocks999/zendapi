<?php

class Application_Model_ApiDocs {

    private $api_doc_id;
    private $api_url;
    private $requestType;
    private $params;
    private $desc;
    private $response;

    public function __construct($api_row = NULL) {
        if (!is_null($api_row))
        {
            $this->api_doc_id = $api_row->api_doc_id;
            $this->api_url = $api_row->api_url;
            $this->requestType = $api_row->requestType;
            $this->params = $api_row->params;
            $this->desc = $api_row->desc;
            $this->response = $api_row->response;
        }
    }

    public function __set($name, $value) {
        $this->$name = $value;
    }

    public function __get($name) {
        return $this->$name;
    }

}
