<?php

class Api_LoginController extends Zend_Controller_Action {

    public function indexAction() {
        $request = $this->getRequest();
        $request_type = $request->getParam("request_type", false);
        $username = $request->getParam("username");
        $password = $request->getParam("password");

        $userMapper = new Application_Model_UserMapper();
        $userinfoMapper = new Application_Model_UserinfoMapper();
        $betMapper = new Application_Model_BetMapper();
        $errors = array();

        //if ($request->isPost()) {

            if ($request_type) {
                if ($request_type == "login") {

                    if (empty($username)) {
                        $errors[] = "Username Should not be empty.";
                    }
                    if (empty($password)) {
                        $errors[] = "Password Should not be empty.";
                    }
                    if (count($errors) == 0) {
						$user = $userMapper->checkUserApp($username,$password);
                        if ($user) {
							$token = md5($user->user_id);
							if($userinfoMapper->setUserToken($user->user_id,$token)){
								$bets = $betMapper->getUserBetNumbers($user->user_id);
								$userinfo = $userinfoMapper->getUserinfo($user->user_id);
								$response = array(
									'id'=>$user->user_id,
									'agent_id'=>$user->agent_id,
									'distributor_id'=>$user->distributor_id,
									'token'=>$token,
									'chips'=>$userinfo->total_chips,
									'score'=>$userinfo->score,
									'today_bonus'=>50,
									'last_wheels'=>array(12,20,3,11,15,9,7,32,30,11),
									'users'=>$bets,
									);
							}else{
								$errors[] = "Something went wrong. Please try again!";
							}
                        } else {
                            $errors[] = "Invalid username and password!";
                        }
                    }
				}
            }
        /*}else{
			$errors[] = "Something went wrong. Please try again!";
		}*/
		if(count($errors)==0){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }

    public function logoutAction() {
		$request = $this->getRequest();
        $request_type = $request->getParam("request_type", false);
        $user_id = $request->getParam("user_id");
        $token = $request->getParam("token");


        $userMapper = new Application_Model_UserMapper();
        $userinfoMapper = new Application_Model_UserinfoMapper();

        $errors = array();

        //if ($request->isPost()) {

            if ($request_type) {
                if ($request_type == "logout") {

                    if (empty($user_id)) {
                        $errors[] = "User Id Should not be empty.";
                    }
                    if (empty($token)) {
                        $errors[] = "Token Should not be empty.";
                    }
                    if (count($errors) == 0) {
						$user = $userinfoMapper->getUserToken($user_id);
                        if ($user->token == $token) {
							$token = '';
							if($userMapper->setUserToken($user->user_id,$token)){
								$response = array('message'=>'You have successfully logged out!');
								
							}else{
								$errors[] = "Something went wrong. Please try again!";
							}
                        } else {
                            $errors[] = "Invalid token!";
                        }
                    }
				}
            }
        /*}else{
			$errors[] = "Something went wrong. Please try again!";
		}*/
		if(count($errors)==0){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }
	public function userprofileAction(){
		$request = $this->getRequest();
        $user_ids = $request->getParam("user_id");

		if (empty($user_ids)) {
			$errors[] = "User Id Should not be empty.";
		}else{
			$betMapper = new Application_Model_BetMapper();
			$response = array();
			foreach($user_ids as $user_id){
				$response[] = array('user_id'=>$user_id,'number'=>$betMapper->getLastBetNumber($user_id));
			}
		}

		if(count($errors)==0){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
	}
	public function requestchipsAction(){
		$request = $this->getRequest();
        $user_id = $request->getParam("user_id");
        $agent_id = $request->getParam("agent_id");
        $chips = $request->getParam("chips");
        if ($user_id) {
			$userchipsreqMapper = new Application_Model_UserchipsreqMapper();
			$req = $userchipsreqMapper->sendRequest($user_id,$agent_id,$chips);
			if(!$req){
				$errors[] = "Something went wrong. Please try again!";
			}else{
				$response = array('msg'=>'Chips request placed successfully!!!','id'=>$req);
			}
			
		}else{
			$errors[] = "Something went wrong. Please try again!";
		}
		if(count($errors)==0){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
	}
}
