<?php
class Api_LeaderboardController extends Zend_Controller_Action {
    
	public function indexAction() {
        $userinfoMapper = new Application_Model_UserinfoMapper();
        $response = $userinfoMapper->score();
		if($response){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = array('message'=>'Something is wrong. Please try again!');
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }
	
	public function contentAction(){
		$request = $this->getRequest();
        $page_name = $request->getParam("page_name");
		
        $staticcontentMapper = new Application_Model_StaticcontentMapper();
        $response = $staticcontentMapper->getContent($page_name);
        //print_r($response);die;
		if($response){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = array('message'=>'Something is wrong. Please try again!');
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
	}
	
	public function statisticsAction(){
        $tablenumberMapper = new Application_Model_TablenumberMapper();
        $response = $tablenumberMapper->getContent();
		if($response){
			$responsecode = 200;
		}else{
			$responsecode = 400;
			$response = array('message'=>'Something is wrong. Please try again!');
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
	}
}

