<?php

class Api_BetController extends Zend_Controller_Action {

    public function indexAction() {
        $request = $this->getRequest();
        $user_id = $request->getParam("user_id", false);
        $numbers = $request->getParam("numbers");
        $total_amount = $request->getParam("total_amount");
        $betMapper = new Application_Model_BetMapper();
		$userinfoMapper = new Application_Model_UserinfoMapper();
		$chiptransactionMapper = new Application_Model_ChipTransactionMapper();/*Pradeep*/
        $errors = array();
		if ($request->isPost()) { 
			if ($user_id) { 
				if (empty($numbers)) {
					$errors[] = "Please select number.";
				}
				if (empty($total_amount)) {
					$errors[] = "Please select number of chips.";
				}
				if (count($errors) == 0) {
					for($i=0;$i<count($numbers);$i++){
						$userinfo = $userinfoMapper->getUserinfo($user_id);
						if($userinfo->total_chips >= $total_amount[$i]){
							$bet = $betMapper->addBet($user_id,$numbers[$i],$total_amount[$i]);
							$total_chips = $userinfo->total_chips - $total_amount[$i];
							$data = array('total_chips'=>$total_chips);
							$where = array('user_id = ?'=>$user_id);
							$userinfoMapper->updateUserinfo($data,$where);
							/* Add chip transaction in database */
							$data = array(
										'user_id'=>$user_id,
										'type'=>'substrate',
										'amount'=>$total_amount[$i],
										'total_amount'=>$total_chips,
										'description'=>'Place bet on numbers:'.$numbers[$i]
										);
							$where = array('user_id = ?'=>$user_id);/*Pradeep*/
							$chiptransactionMapper->insertchiptransaction($data,$where);/*Pradeep*/
							if(!$bet){
								$errors[] = "Something went wrong. Please try again!";
							}else{
								$betsId[] = $bet;
							}
						}else{
							$errors[] = "Your bet has been not place due to insufficient chips. Please contact your agent to buy chips.";
						}
					}
				}
			}else{
				$errors[] = "Something went wrong. Please try again!";
			}
		}else{
			$errors[] = "Something went wrong. Please try again!";
		}
		if(count($errors)==0){
			$responsecode = 200;
			$response = array('bet_id'=>$betsId,'message'=>'Bet Placed successfully!');
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }


	public function getwinnerAction() {
        $request = $this->getRequest();
        $user_id = $request->getParam("user_id", false);
        $bet_id = $request->getParam("bet_id");
        $errors = array();
		$betMapper = new Application_Model_BetMapper();
		$userinfoMapper = new Application_Model_UserinfoMapper();
		$chiptransactionMapper = new Application_Model_ChipTransactionMapper();
		$tablenumberMapper = new Application_Model_TablenumberMapper();
		if ($request->isPost()) {
			if ($user_id) {
				if (isset($bet_id)) {
					$betinfo = $betMapper->getBet($user_id,$bet_id);
					if($betinfo){
						if($betinfo['winned_num_id']==''){
							$tablenumbers = array('0'=>0,'1'=>0,'2'=>0,'3'=>0,'4'=>0,'5'=>0,'6'=>0,'7'=>0,'8'=>0,'9'=>0,'10'=>0,'11'=>0,'12'=>0,'13'=>0,'14'=>0,'15'=>0,'16'=>0,'17'=>0,'18'=>0,'19'=>0,'20'=>0,'21'=>0,'22'=>0,'23'=>0,'24'=>0,'25'=>0,'26'=>0,'27'=>0,'28'=>0,'29'=>0,'30'=>0,'31'=>0,'32'=>0,'33'=>0,'34'=>0,'35'=>0,'36'=>0,'00'=>0);
							$bets = $betMapper->getUserinfo();
							if($bets){
								foreach($bets as $bet){
									$numbers = explode(',',$bet['numbers']);
									foreach($tablenumbers as $key=>$show) {
										$selectNumber = $key;
										if($key==37){
											$selectNumber = '00';
										}
										if(in_array($key,$numbers)){
											$tablenumbers[$key] = $tablenumbers[$key] + (36/count($numbers)*$bet['total_amount']);
										}
									}
								}
								$min=INF;
								$winnernumber;
								$size = sizeof($tablenumbers);
								foreach ($tablenumbers as $key => $value) {
									if($value < $min && $value!=0) {
										$min = $value;
										$winnernumber = $key;
									}
								}
								$winnerUsers = array();
								foreach($bets as $bet){
									$numbers = explode(',',$bet['numbers']);
									if(in_array($winnernumber,$numbers)){
										$winnerUsers[] = array('user_id'=>$bet['user_id'],'amount'=>(36/count($numbers)*$bet['total_amount']));
									}
								}
								$setWinner = $betMapper->setWinner($winnernumber);
								if($setWinner){
									$total_win = 0;
									foreach($winnerUsers as $winnerUser){
										$total_win = $total_win + $winnerUser['amount'];
										$userinfo = $userinfoMapper->getUserinfo($winnerUser['user_id']);
										$total_chips = $userinfo->total_chips + $winnerUser['amount'];
										$score = $userinfo->score + $winnerUser['amount'];
										$data = array('total_chips'=>$total_chips,'score'=>$score);
										$where = array('user_id = ?'=>$winnerUser['user_id']);
										$userinfoMapper->updateUserinfo($data,$where);
										/* Add chip transaction in database */
										$data = array(
													'user_id'=>$winnerUser['user_id'],
													'type'=>'add',
													'amount'=>$winnerUser['amount'],
													'total_amount'=>$total_chips,
													'description'=>'Win the chips.'
													);
										$where = array('user_id = ?'=>$winnerUser['user_id']);
							            $chiptransactionMapper->insertchiptransaction($data,$where);
									}
									$tablenumberMapper->updateNumber($winnernumber,$total_win);
								}else{
									$errors[] = "Something went wrong. Please try again!";
								}
							}else{
								$errors[] = 'No bets are present.';
							}
						}else{
							$winnernumber = $betinfo['winned_num_id'];
						}
					}else{
						$errors[] = "Bet not present. Please try again!";
					}
				}else{
					$winner = $betMapper->getLastWinner();
					$winnernumber = $winner["winned_num_id"];
				}
			}else{
				$errors[] = "Something went wrong. Please try again!";
			}

		}else{
			$errors[] = "Something went wrong. Please try again!";
		}
		if(count($errors)==0){
			$responsecode = 200;
			$response = array('winner'=>$winnernumber);
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }


    public function undobetAction() {
        $request = $this->getRequest();
        $user_id = $request->getParam("user_id", false);
        $bet_ids = $request->getParam("bet_id", false);

        $betMapper = new Application_Model_BetMapper();
		$userinfoMapper = new Application_Model_UserinfoMapper();
        $errors = array();
        //$bet_ids = $betMapper->getLastBet($user_id);
		if ($request->isPost()) { 
			if ($user_id) {
				if (!count($bet_ids)) {
					$errors[] = "Bet not present. Please try again!";
				}
				if (count($errors) == 0) {
					foreach($bet_ids as $bet_id){
						$userinfo = $userinfoMapper->getUserinfo($user_id);
						$betinfo = $betMapper->getBet($user_id,$bet_id);
						if($betinfo){
							$bet = $betMapper->deleteBet($user_id,$bet_id);
							if($bet){
								$total_chips = $userinfo->total_chips + $betinfo['total_amount'];
								$data = array('total_chips'=>$total_chips);
								$where = array('user_id = ?'=>$user_id);
								$userinfoMapper->updateUserinfo($data,$where);
							}else{
								$errors[] = "Something went wrong. Please try again!";
							}
						}else{
							$errors[] = "Bet not present. Please try again!";
						}
					}
				}
			}else{
				$errors[] = "Something went wrong. Please try again!";
			}
		}else{
			$errors[] = "Something went wrong. Please try again!";
		}
		if(count($errors)==0){
			$responsecode = 200;
			$response = array('message'=>'Bet removed successfully!');
		}else{
			$responsecode = 400;
			$response = $errors;
		}
		http_response_code($responsecode);
		header('Content-Type: application/json');
		echo json_encode($response);
		die;
    }
}