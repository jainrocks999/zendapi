<?php

class Admin_AttributesController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("catalog_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction() {

        $attributeMapper = new Application_Model_AttributesMapper();
        $request = $this->getRequest();
        $store_id = $request->getParam("id");


        $attributeValueMapper = new Application_Model_AttributeValuesMapper();

        $categoryAttributeMapper = new Application_Model_CategoryAttributesMapper();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");
                if ($request_type == "delete") {
                    $attribute_id = $request->getParam("id");
                    $attribute = $attributeMapper->getAttributeById($attribute_id);
//                echo $id;exit;
                    if ($attributeMapper->deleteAttributeById($attribute_id)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = $attribute->__get("attribute_name") . " " . "deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting Attribute";
                    }
                } elseif ($request_type == "deleteCatAttr") {
                    $CatAttrId = $request->getParam("id");
                echo $CatAttrId;exit;
                    if ($categoryAttributeMapper->deleteCategoryAttributeById($CatAttrId)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "Category Attribute deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting Attribute";
                    }
                }
            }
//            var_dump($store_id);exit;
//            var_dump($_SESSION["store_id"]);exit;
            $attributes = $attributeMapper->getAllAttributesByStoreId($store_id);

            if ($attributes) {
                $paginator = Zend_Paginator::factory($attributes);
                $item_per_page = $request->getParam("item_per_page", 10);
                $paginator->setItemCountPerPage($item_per_page);
                $page = $request->getParam("page", 1);
                $paginator->setCurrentPageNumber($page);
                $attributes = $paginator;
            }
            $this->view->attributes = $attributes;

            $storeMapper = new Application_Model_StoresMapper();
            $stores = $storeMapper->getAllStores();
            $this->view->stores = $stores;
        }
    }

    public function addAction() {
        $storeMapper = new Application_Model_StoresMapper();

        $attributeMapper = new Application_Model_AttributesMapper();
        $attribute = new Application_Model_Attributes();

        $categoriesMapper = new Application_Model_CategoriesMapper();
        $categories = $categoriesMapper->getAllCategories();
        $this->view->categories = $categories;


        $categoryAttributeMapper = new Application_Model_CategoryAttributesMapper();

        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "add") {

                    $atype = $request->getParam("atype");
                    $aname = $request->getParam("aname");
                    $avalues = $request->getParam("avalues");
                    $category_ids = $request->getParam("category_ids");
                    $store_id = $request->getParam("store_id");

                    if (empty($atype)) {
                        $errors[] = "Select Type";
                    } else {
                        if ($atype == "SELECT") {
                            if (count($avalues) == 0) {
                                $errors[] = "Attribute Value is empty";
                            }
                        }
                    }
                    if (empty($aname)) {
                        $errors[] = "Enter Name";
                    }
                    if (empty($store_id)) {
                        $errors[] = "Enter Store Name";
                    }
                    if (count($errors) == 0) {

                        $attribute->__set("attribute_type", $atype);
                        $attribute->__set("attribute_name", $aname);
                        $attribute->__set("store_id", $store_id);
                        $id = $attributeMapper->addNewAttribute($attribute);
//                        print_r($id);exit;

                        $attributeValueMapper = new Application_Model_AttributeValuesMapper();
                        $attributeValue = new Application_Model_AttributeValues();


                        if ($id) {
                            if (count($category_ids) > 0) {
                                $miscLib = new My_Misc();

                                foreach ($category_ids as $cat_id) {
                                    $miscLib->doMappingForCatAttr($cat_id, $id, $store_id);
                                }
                            }
                            if ($atype == "SELECT") {
                                $errorFlag = FALSE;
                                foreach ($avalues as $avalue) {
                                    $attributeValue->__set("attribute_id", $id);
                                    $attributeValue->__set("attribute_value", $avalue);

                                    if ($attributeValueMapper->addNewAttributevalue($attributeValue)) {
                                        
                                    } else {
                                        $errorFlag = TRUE;
                                    }
                                }
                                if ($errorFlag) {
                                    $this->view->hasMessage = true;
                                    $this->view->messageType = "danger";
                                    $this->view->message = "error while adding attribute value";
                                } else {
                                    $this->view->hasMessage = true;
                                    $this->view->messageType = "success";
                                    $this->view->message = "Attribute has been added successfully";
                                }
                            } else {
                                $this->view->hasMessage = true;
                                $this->view->messageType = "success";
                                $this->view->message = "Attribute has been added successfully";
                            }
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding Attribute";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }

            $attributes = $attributeMapper->getAllAttributes();
            $this->view->attributes = $attributes;

            $stores = $storeMapper->getAllStores();
            $this->view->stores = $stores;
        }
    }

    public function editAction() {
        $storeMapper = new Application_Model_StoresMapper();

        $stores = $storeMapper->getAllStores();
        $this->view->stores = $stores;

        $attributeValuesMapper = new Application_Model_AttributeValuesMapper();

        $categoryMapper = new Application_Model_CategoriesMapper();
        $categories = $categoryMapper->getAllCategories();
        $this->view->categories = $categories;

        $categoryAttributeMapper = new Application_Model_CategoryAttributesMapper();

        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $attributeMapper = new Application_Model_AttributesMapper();
        $attribute = $attributeMapper->getAttributeById($id);
        $this->view->id = $id;
        $this->view->attribute = $attribute;

//        $attributeMapper = new Application_Model_AttributesMapper();
//        $attributes = $attributeMapper->getAllAttributes();
//        $this->view->attributes = $attributes;

        if ($request->isPost()) {

            $request_type = $request->getParam("request_type");

            if ($request_type == "delete") {
                $id = $request->getParam("attribute_category_id");
                //  echo $id;exit;
                if ($categoryAttributeMapper->deleteCategoryAttributeById($id)) {
                    $this->view->hasMessage = true;
                    $this->view->messageType = "success";
                    $this->view->message = "Category deleted successfully";
                } else {
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = "Error while deleting Attribute";
                }
            } elseif ($request_type == "edit") {

                $aname = $request->getParam("aname");
                $atype = $request->getParam("atype");
                $store_id = $request->getParam("store_id");
                $avalues = $request->getParam("attribute_values");

                if (empty($aname)) {
                    $errors[] = "Enter Name";
                }
                if (empty($atype)) {
                    $errors[] = "Select Type";
                } else {
                    if ($atype == "SELECT") {
                        if (count($avalues) == 0) {
                            $errors[] = "Please add some attribute value for this attribute";
                        }
                    }
                }
                if (empty($store_id)) {
                    $errors[] = "Select Store Name";
                }

                if (count($errors) == 0) {

                    $attribute->__set("attribute_name", $aname);
                    $attribute->__set("attribute_type", $atype);
                    $attribute->__set("store_id", $store_id);


                    if ($attributeMapper->updateAttribute($attribute)) {

                        if ($atype == "SELECT") {
                            foreach ($avalues as $value) {
                                $attribute_value_id = $value['id'];
                                $attribute_value = $value['value'];

                                if ($attribute_value_id) {
                                    $data_value = $attributeValuesMapper->getAttributeValueById($attribute_value_id);
                                    if ($data_value) {
                                        $data_value->__set("attribute_value", $attribute_value);
                                        $attributeValuesMapper->updateAttributeValue($data_value);
                                    }
                                } else {
                                    //   echo $attribute_value . "/" . $id;
                                    //   exit;
                                    $attributeValuesModel = new Application_Model_AttributeValues();
                                    $attributeValuesModel->__set("attribute_value", $attribute_value);
                                    $attributeValuesModel->__set("attribute_id", $id);
                                    $attribute_value_id = $attributeValuesMapper->addNewAttributeValue($attributeValuesModel);
                                    if ($attribute_value_id) {
                                        $this->view->hasMessage = true;
                                        $this->view->messageType = "success";
                                        $this->view->message = "Attribute Value updated Successfully";
                                    } else {
                                        $this->view->hasMessage = true;
                                        $this->view->messageType = "danger";
                                        $this->view->message = "Error while updating Attribute Value";
                                    }
                                }
                            }
                        } else {
                            //
                        }
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while updating Attribute Value";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            } elseif ($request_type == "attribute_value_delete") {
                $attribute_value_id = $request->getParam("attribute_value_id");
//                echo $id;exit;
                if ($attributeValuesMapper->deleteAttributeValueById($attribute_value_id)) {
                    $this->view->hasMessage = true;
                    $this->view->messageType = "success";
                    $this->view->message = "Attribute Value deleted successfully";
                } else {
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = "Error while deleting Attribute Value";
                }
            }
        }
    }

}
