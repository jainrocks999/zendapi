<?php

class Admin_AuthController extends Zend_Controller_Action {

    protected $_auth;

    public function init() {
        $this->_auth = new My_Auth("casino_session");

        $this->_helper->layout()->setlayout('admin_login');
    }

    public function indexAction() {
        // action body
        $request = $this->getRequest();
        $request_type = $request->getParam("request_type", false);
        $username = $request->getParam("username");
        $password = $request->getParam("password");


        $adminMapper = new Application_Model_AdminsMapper();
        //$admim = new Application_Model_Admins();
        // $server = $request->getServer();
//        $ip = $_SERVER['REMOTE_ADDR'];

        $errors = array();

        if ($request->isPost()) {

            if ($request_type) {
                if ($request_type == "login") {

                    if (empty($username)) {
                        $errors[] = "Username Should not be empty";
                    }
                    if (empty($password)) {
                        $errors[] = "Password Should not be empty";
                    }
                    if (count($errors) == 0) {
                        if ($this->_process($request->getParams())) {

                            $admin_id = $this->_auth->getIdentity()->id;
                            $this->view->id = $admin_id;
                            
                            $store_id = $this->_auth->getIdentity()->store_id;
//                            var_dump($store_id);exit;
                            $this->view->store_id = $store_id;
//                            $admin = $adminMapper->getAdminById($admin_id);
//                            $admin->__set("last_login_ip", $ip);

                            $this->_helper->redirector('index', 'index');
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Invalid username and password";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }
        }
    }

    protected function _process($values) {

        // Get our authentication adapter and check credentials
        $adapter = $this->_getAuthAdapter();

        $adapter->setIdentity($values['username']); // set identity for username

        $adapter->setCredential($values['password']);

        $adminAuth = new My_Auth("casino_session"); // session create

        $auth = $adminAuth;

        $result = $auth->authenticate($adapter); //
    //        print_r($result);exit;
        if ($result->isValid()) {

            $admin = $adapter->getResultRowObject(); // takes the complete colum of that row that i want to take

            $auth->getStorage()->write($admin); // through this line we write in session

            return true;
        }

        return false;
    }

    protected function _getAuthAdapter() {

        $admins = new Application_Model_DbTable_Admins();

        $authAdapter = new Zend_Auth_Adapter_DbTable($admins->getAdapter());

        $authAdapter->setTableName('admin')
                ->setIdentityColumn('username')
                ->setCredentialColumn('password');

        return $authAdapter;
    }

    public function logoutAction() {
        $adminAuth = new My_Auth("casino_session");
        $adminAuth->clearIdentity();
        $this->_helper->redirector('index', 'auth');
    }


}
