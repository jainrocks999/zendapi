<?php

class Admin_AdminsController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("catalog_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction() {

        $adminMapper = new Application_Model_AdminsMapper();
        $admin = new Application_Model_Admins();
        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "add") {

                    $fname = $request->getParam("fname");
                    $lname = $request->getParam("lname");
                    $role = $request->getParam("role");
                    $username = $request->getParam("username");
                    $pass = $request->getParam("pass");
                    $cpass = $request->getParam("cpass");
                    $email = $request->getParam("email");
                    $number = $request->getParam("number");

                    if (empty($fname)) {
                        $errors[] = "Enter First Name";
                    }
                    if (empty($lname)) {
                        $errors[] = "Enter Last Name";
                    }
                    if (empty($role)) {
                        $errors[] = "Select Admin Role";
                    }
                    if (empty($username)) {
                        $errors[] = "Enter Username";
                    }
                    if (empty($pass)) {
                        $errors[] = "Enter Password";
                    }
                    if (empty($cpass)) {
                        $errors[] = "Confirm Password";
                    }
                    if (empty($email)) {
                        $errors[] = "Enter Email";
                    } else {
                        $emailValidator = new Zend_Validate_EmailAddress();
                        if (!$emailValidator->isValid($email)) {
                            $errors[] = "Invalid Email Address";
                        }
                    }
                    if (empty($number)) {
                        $errors[] = "Enter Mobile Number";
                    } else {
                        $digitValidator = new Zend_Validate_Digits();
                        if (!$digitValidator->isValid($number)) {
                            $errors[] = "Invalid Number";
                        } else {
                            $length = strlen($number);
                            if ($length < 10) {
                                $errors[] = "Mobile Number Should be 10 digits long";
                            }
                        }
                    }
                    if($pass!=$cpass){
                        $errors[] ="Password Not Matched";
                    }

                    if (count($errors) == 0) {

                        $admin->__set("admin_fname", $fname);
                        $admin->__set("admin_lname", $lname);
                        $admin->__set("admin_role", $role);
                        $admin->__set("admin_username", $username);
                        $admin->__set("hashed_password", sha1($pass));
                        $admin->__set("admin_email", $email);
                        $admin->__set("admin_number", $number);


                        if ($adminMapper->addNewAdmin($admin)) {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->message = "Admin has been added successfully";
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding student";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                } elseif ($request_type == "delete") {

                    $id = $request->getParam("id");
                    $admin = $adminMapper->getAdminById($id);
                    if ($adminMapper->deleteAdminById($id)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = $admin->__get("admin_fname") . " " . "deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting";
                    }
                }
            }

            $admins = $adminMapper->getAllAdmins();
            $this->view->admins = $admins;
        }
    }

    public function editAction() {

        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $adminMapper = new Application_Model_AdminsMapper();
        $admin = $adminMapper->getAdminById($id);

        $this->view->admin = $admin;

        if ($request->isPost()) {

            $request_type = $request->getParam("request_type");

            if ($request_type == "edit") {

                $fname = $request->getParam("fname");
                $lname = $request->getParam("lname");
                $role = $request->getParam("role");
                $username = $request->getParam("username");
                $email = $request->getParam("email");
                $number = $request->getParam("number");

                if (empty($fname)) {
                    $errors[] = "Enter First Name";
                }
                if (empty($lname)) {
                    $errors[] = "Enter Last Name";
                }
                if (empty($role)) {
                    $errors[] = "Select Admin Role";
                }
                if (empty($username)) {
                    $errors[] = "Enter Username";
                }
                if (empty($email)) {
                    $errors[] = "Enter Email";
                } {
                    $emailValidator = new Zend_Validate_EmailAddress();
                    if (!$emailValidator->isValid($email)) {
                        $errors[] = "Invalid Email Address";
                    }
                }
                if (empty($number)) {
                    $errors[] = "Enter Mobile Number";
                } else {
                    $digitValidator = new Zend_Validate_Digits();
                    if (!$digitValidator->isValid($number)) {
                        $errors[] = "Invalid Number";
                    } else {
                        if (!(strlen($number) == 10)) {
                            $errors[] = "Mobile Number Should be 10 digits long";
                        }
                    }
                }

                if (count($errors) == 0) {

                    $admin->__set("admin_fname", $fname);
                    $admin->__set("admin_lname", $lname);
                    $admin->__set("admin_role", $role);
                    $admin->__set("admin_username", $username);
                    $admin->__set("admin_email", $email);
                    $admin->__set("admin_number", $number);

                    if ($adminMapper->updateAdmin($admin)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "Admin has been updated successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while updating Admin";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            }
        }
    }

}
