<?php

class Admin_DistributorController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("casino_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction() {

        $distributorMapper = new Application_Model_DistributorMapper();
        $distributor = new Application_Model_Distributor();
        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "delete") {

                    $id = $request->getParam("id");
                    $distributor = $distributorMapper->getDistributorById($id);
                    if ($distributorMapper->deleteUserById($id)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = $distributor->__get("name") . " " . "deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting";
                    }
                }
            }

            $distributors = $distributorMapper->getAllDistributors();

            $this->view->distributors = $distributors;
        }
    }

    public function addAction() {

        $distributorMapper = new Application_Model_DistributorMapper();
        $distributor = new Application_Model_Distributor();
        $request = $this->getRequest();
        $errors = array();
        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");
                if ($request_type == "add") {

                    $name = $request->getParam("name");
                    $phone = $request->getParam("phone");
                    $email = $request->getParam("email");
                    $address = $request->getParam("address");
                    $comments = $request->getParam("comments");
                    $password = $request->getParam("password");
                    $username = $request->getParam("username");



                    if (count($errors) == 0) {


                        $distributor->__set("name", $name);
                        $distributor->__set("phone", $phone);
                        $distributor->__set("email", $email);
                        $distributor->__set("address", $address);
                        $distributor->__set("comments", $comments);
                        $distributor->__set("percent_comm", "6");
                        $distributor->__set("password", $password);
                        $distributor->__set("username", $username);
                        $distributor->__set("timestamp", date("Y-m-d"));


                        if ($distributorMapper->addNewDistributor($distributor)) {
                            $this->redirect("/admin/distributor/");
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->message = "Distributor has been added successfully";
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding Distributor";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }
        }
    }

    public function editAction() {

        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $distributorMapper = new Application_Model_DistributorMapper();
        $distributor = $distributorMapper->getDistributorById($id);

        $this->view->distributor = $distributor;

        if ($request->isPost()) {

            $request_type = $request->getParam("request_type");

            if ($request_type == "edit") {

                $name = $request->getParam("name");
                $phone = $request->getParam("phone");
                $email = $request->getParam("email");
                $address = $request->getParam("address");
                $comments = $request->getParam("comments");
                $password = $request->getParam("password");
                $username = $request->getParam("username");



                if (count($errors) == 0) {


                    $distributor->__set("name", $name);
                    $distributor->__set("phone", $phone);
                    $distributor->__set("email", $email);
                    $distributor->__set("address", $address);
                    $distributor->__set("comments", $comments);
                    $distributor->__set("percent_comm", "6");
                    $distributor->__set("password", $password);
                    $distributor->__set("username", $username);
                    $distributor->__set("timestamp", date("Y-m-d"));


                    if ($distributorMapper->updateDistributor($distributor)) {
                        $this->redirect("/admin/distributor/");
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "Distributor has been updated successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while updating Distributor";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            }
        }
    }

    public function viewAction() {
        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $distributorMapper = new Application_Model_DistributorMapper();
        $distributor = $distributorMapper->getDistributorById($id);

        $this->view->distributor = $distributor;
    }

}
