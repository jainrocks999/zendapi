<?php

class Admin_LoginsController extends Zend_Controller_Action {

    protected $_auth;

    public function init() {
        $this->_auth = new My_Auth("store_session");
        $this->_helper->layout()->setlayout('admin_login');
    }

    public function indexAction() {
        // action body
        $request = $this->getRequest();
        $request_type = $request->getParam("request_type", false);



        $errors = array();

        if ($request_type) {
            if ($request_type == "store-login") {
                $username = $request->getParam("store_email");
                $password = $request->getParam("password");
//                    echo $username;
//                    exit;


                if (count($errors) == 0) {

                    if ($this->_processForStore($request->getParams())) {
                        //echo "in";exit;
                        $store_id = $this->_auth->getIdentity()->store_id;
                        $this->view->store_id = $store_id;
//                            echo $store_id;
//                            exit;

                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Invalid username and password";
                        $this->_helper->redirector('index', 'index');
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Invalid username and password";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            }
        }
    }

    protected function _processForStore($values) {

        // Get our authentication adapter and check credentials
        $adapter = $this->_getAuthAdapter();

        $adapter->setIdentity($values['store_email']); // set identity for username

        $adapter->setCredential($values['password']);

        $loginAuth = new My_Auth("store_session"); // session create

        $auth = $loginAuth;

        $result = $auth->authenticate($adapter); //
//                print_r($result);exit;
        if ($result->isValid()) {

            $admin = $adapter->getResultRowObject(); // takes the complete column of that row that i want to take

            $auth->getStorage()->write($admin); // through this line we write in session

            return true;
        }

        return false;
    }

    protected function _processForAdmin($values) {

        // Get our authentication adapter and check credentials
        $adapter = $this->_getAuthAdapter1();

        $adapter->setIdentity($values['username']); // set identity for username

        $adapter->setCredential($values['password']);

        $loginAuth = new My_Auth("store_session"); // session create

        $auth = $loginAuth;

        $result = $auth->authenticate($adapter); //
        //        print_r($result);exit;
        if ($result->isValid()) {

            $admin = $adapter->getResultRowObject(); // takes the complete colum of that row that i want to take

            $auth->getStorage()->write($admin); // through this line we write in session

            return true;
        }

        return false;
    }

    protected function _getAuthAdapter() {

        $stores = new Application_Model_DbTable_Stores();

        $authAdapter = new Zend_Auth_Adapter_DbTable($stores->getAdapter());

        $authAdapter->setTableName('stores')
                ->setIdentityColumn('store_email')
                ->setCredentialColumn('hashed_password')
                ->setCredentialTreatment('SHA1(?)');

        return $authAdapter;
    }

    protected function _getAuthAdapter1() {

        $admins = new Application_Model_DbTable_Admins();

        $authAdapter = new Zend_Auth_Adapter_DbTable($admins->getAdapter());

        $authAdapter->setTableName('admin')
                ->setIdentityColumn('admin_username')
                ->setCredentialColumn('hashed_password')
                ->setCredentialTreatment('SHA1(?)');

        return $authAdapter;
    }

    public function logoutAction() {
        $loginAuth = new My_Auth("store_session");
        $loginAuth->clearIdentity();
        $this->_helper->redirector('index', 'logins');
    }

  

}
