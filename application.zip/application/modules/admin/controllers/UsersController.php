<?php

class Admin_UsersController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("casino_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction() {

        $userMapper = new Application_Model_UserMapper();
        $user = new Application_Model_User();
        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "delete") {

                    $id = $request->getParam("id");
                    $user = $userMapper->getUserById($id);
                    if ($userMapper->deleteUserById($id)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = $user->__get("username") . " " . "deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting";
                    }
                }
            }

            $users = $userMapper->getAllUsers();
            $this->view->users = $users;
        }
    }

    public function addAction() {
        $userMapper = new Application_Model_UserMapper();
        $user = new Application_Model_User();
        $dMapper = new Application_Model_DistributorMapper();
        $dis = $dMapper->getAllDistributors();
        $this->view->dis = $dis;

        $aMapper = new Application_Model_AgentMapper();
        $agent = $aMapper->getAllAgents();
        $this->view->agent = $agent;

        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "add") {

                    $name = $request->getParam("name");
                    $email = $request->getParam("email");
                    $password = $request->getParam("password");
                    $username = $request->getParam("username");
                    $phone = $request->getParam("phone");
                    $address = $request->getParam("address");
                    $agent_id = $request->getParam("agent_id");
                    $distributor_id = $request->getParam("distributor_id");
                    $referral_code = $request->getParam("referral_code");


                    if (count($errors) == 0) {

                        $user->__set("name", $name);
                        $user->__set("email", $email);
                        $user->__set("password", $password);
                        $user->__set("phone", $phone);
                        $user->__set("address", $address);
                        $user->__set("username", $username);
                        $user->__set("agent_id", $agent_id);
                        $user->__set("distributor_id", $distributor_id);
                        $user->__set("referral_code", $referral_code);
                        $user->__set("user_type", "PU");
                        $user->__set("timestamp", date("Y-m-d"));


                        if ($userMapper->addNewUser($user)) {
                            $this->redirect("/admin/users/");
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->message = "User has been added successfully";
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding student";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }
        }
    }

    public function editAction() {

        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $userMapper = new Application_Model_UserMapper();
        $user = $userMapper->getUserById($id);

        $dMapper = new Application_Model_DistributorMapper();
        $dis = $dMapper->getAllDistributors();
        $this->view->dis = $dis;

        $aMapper = new Application_Model_AgentMapper();
        $agent = $aMapper->getAllAgents();
        $this->view->agent = $agent;


        $this->view->user = $user;

        if ($request->isPost()) {

            $request_type = $request->getParam("request_type");

            if ($request_type == "edit") {


                $name = $request->getParam("name");
                $email = $request->getParam("email");
                $password = $request->getParam("password");
                $username = $request->getParam("username");
                $phone = $request->getParam("phone");
                $address = $request->getParam("address");
                $agent_id = $request->getParam("agent_id");
                $distributor_id = $request->getParam("distributor_id");
                $referral_code = $request->getParam("referral_code");


                if (count($errors) == 0) {

                    $user->__set("name", $name);
                    $user->__set("email", $email);
                    $user->__set("password", $password);
                    $user->__set("phone", $phone);
                    $user->__set("address", $address);
                    $user->__set("username", $username);
                    $user->__set("agent_id", $agent_id);
                    $user->__set("distributor_id", $distributor_id);
                    $user->__set("referral_code", $referral_code);
                    $user->__set("user_type", "PU");
                    $user->__set("timestamp", date("Y-m-d"));


                    if ($userMapper->updateUser($user)) {
                        $this->redirect("/admin/users/");
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "User has been updated successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while updating User";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            }
        }
    }

    protected function _imageUpload($input_name, $file_prefix) {
        $adapter = new Zend_File_Transfer_Adapter_Http();
        //$adapter->addValidator('Extension', false, 'jpg,png,gif');

        defined('PUBLIC_PATH') || define('PUBLIC_PATH', realpath(dirname(dirname(dirname(dirname(dirname(__FILE__)))))));
        $files = $adapter->getFileInfo();
        //echo "<pre>";
        //print_r($adapter);
        //echo "</pre>";
        $uniqId = time();

        foreach ($files as $file => $info) {

            if ($file == $input_name and strlen($info["name"]) > 0) {
                $adapter->setDestination(PUBLIC_PATH . "/public_html/uploads/user_profiles/");
                $originalFilename = pathinfo($adapter->getFileName($file));
                //$extesion = $file["extension"];
                $newFilename = $file_prefix . '-' . $uniqId . '.' . $originalFilename['extension'];
                if ($newFilename) {
                    $adapter->addFilter('Rename', $newFilename, $file);
                    $adapter->receive($file);
                }
                return $newFilename;    //        $products->__set("product_thumbnail",$newFilename);
            }
        }
    }

    public function viewAction() {
        $request = $this->getRequest();
        $id = $request->getParam("id");
        $userMapper = new Application_Model_UserMapper();
        $users = $userMapper->getUserById($id);
        $this->view->users = $users;
    }

}
