<?php

class Admin_ApiDocsController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("catalog_session");
        if (!$auth->hasIdentity())
        {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function preDispatch() {
        //$this->view->render('api-docs/_menu.phtml');
    }

    public function indexAction() {
        $apiMapper = new Application_Model_ApiDocsMapper();
        $api = new Application_Model_ApiDocs();
        $errors = array();


        $request = $this->getRequest();

        if ($request)
        {
            if ($request->isPost())
            {
                $request_type = $request->getParam("request_type");

                if ($request_type == "add")
                {


                    $api_url = $request->getParam("api_url");
                    $requestType = $request->getParam("requestType");
                    $params = $request->getParam("params");
                    $desc = $request->getParam("desc");
                    $response = $request->getParam("response");


                    if (empty($api_url))
                    {
                        $errors[] = "The URL of API is required";
                    }
                    if (empty($requestType))
                    {
                        $errors[] = "The request type is required";
                    }
                    if (empty($params))
                    {
                        $params = "NA";
                    }

                    if (empty($response))
                    {
                        $errors[] = "Response must be added";
                    }
                    if (count($errors) == 0)
                    {

                        $api->__set("api_url", $api_url);
                        $api->__set("requestType", $requestType);
                        $api->__set("params", $params);
                        $api->__set("desc", $desc);
                        $api->__set("response", $response);


                        if ($apiMapper->addNewApi($api))
                        {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->message = "API has been added successfully";
                        }
                        else
                        {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding API";
                        }
                    }
                    else
                    {
                        $errorString = "";
                        foreach ($errors as $error)
                        {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
                elseif ($request_type == "delete")
                {
                    $id = $request->getParam("id");
                    if ($apiMapper->deleteApiById($id))
                    {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "API has been deleted successfully";
                    }
                    else
                    {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting API";
                    }
                }
            }
            $api = $apiMapper->getAllApis();
            $this->view->apis = $api;
        }
    }

    public function editAction() {
        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $apiMapper = new Application_Model_ApiDocsMapper();
        $api = $apiMapper->getApiById($id);


        $this->view->api = $api;

        if ($request)
        {
            if ($request->isPost())
            {
                $request_type = $request->getParam("request_type");
                if ($request_type == "edit")
                {

                    $api_url = $request->getParam("api_url");
                    $requestType = $request->getParam("requestType");
                    $params = $request->getParam("params");
                    $desc = $request->getParam("desc");
                    $response = $request->getParam("response");




                    if (empty($api_url))
                    {
                        $errors[] = "The URL of API is required";
                    }
                    if (empty($requestType))
                    {
                        $errors[] = "The request type is required";
                    }

                    if (empty($response))
                    {
                        $errors[] = "Response must be added";
                    }
                    if (count($errors) == 0)
                    {

                        $api->__set("api_url", $api_url);
                        $api->__set("requestType", $requestType);
                        $api->__set("params", $params);
                        $api->__set("desc", $desc);
                        $api->__set("response", $response);

                        if ($apiMapper->updateApi($api))
                        {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->view = "API has been updated successfully";
                        }
                        else
                        {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->view = "Error while updating API";
                        }
                    }
                    else
                    {
                        $errorString = "";
                        foreach ($errors as $error)
                        {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }
        }
    }

}
