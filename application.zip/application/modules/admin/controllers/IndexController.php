<?php

class Admin_IndexController extends Zend_Controller_Action
{

    public function init()
    {
        $auth = new My_Auth("casino_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index','auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction()
    {
        
    }


}

