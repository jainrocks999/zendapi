<?php

class Admin_AgentController extends Zend_Controller_Action {

    public function init() {
        $auth = new My_Auth("casino_session");
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('index', 'auth');
        }
        $this->_helper->layout()->setLayout("admin");
    }

    public function indexAction() {

        $agentMapper = new Application_Model_AgentMapper();
        $agent = new Application_Model_Agent();
        $errors = array();

        $request = $this->getRequest();

        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");

                if ($request_type == "delete") {

                    $id = $request->getParam("id");
                    $agent = $agentMapper->getAgentById($id);
                    if ($agentMapper->deleteUserById($id)) {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = $agent->__get("name") . " " . "deleted successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while deleting";
                    }
                }
            }

            $agents = $agentMapper->getAllAgents();

            $this->view->agents = $agents;
        }
    }

    public function addAction() {

        $agentMapper = new Application_Model_AgentMapper();
        $agent = new Application_Model_Agent();
        $dMapper = new Application_Model_DistributorMapper();
        $dis = $dMapper->getAllDistributors();
        $this->view->dis = $dis;

        $request = $this->getRequest();
        $errors = array();
        if ($request) {
            if ($request->isPost()) {
                $request_type = $request->getParam("request_type");
                if ($request_type == "add") {

                    $name = $request->getParam("name");
                    $phone = $request->getParam("phone");
                    $email = $request->getParam("email");
                    $address = $request->getParam("address");
                    $distributor = $request->getParam("distributor_id");
                    $comments = $request->getParam("comments");
                    $password = $request->getParam("password");
                    $username = $request->getParam("username");



                    if (count($errors) == 0) {


                        $agent->__set("name", $name);
                        $agent->__set("phone", $phone);
                        $agent->__set("email", $email);
                        $agent->__set("address", $address);
                        $agent->__set("distributor_id", $distributor);
                        $agent->__set("comments", $comments);
                        $agent->__set("percent_comm", "5");
                        $agent->__set("password", $password);
                        $agent->__set("username", $username);
                        $agent->__set("timestamp", date("Y-m-d"));


                        if ($agentMapper->addNewAgent($agent)) {
                            $this->redirect("/admin/agent/");
                            $this->view->hasMessage = true;
                            $this->view->messageType = "success";
                            $this->view->message = "Agent has been added successfully";
                        } else {
                            $this->view->hasMessage = true;
                            $this->view->messageType = "danger";
                            $this->view->message = "Error while adding Agent";
                        }
                    } else {
                        $errorString = "";
                        foreach ($errors as $error) {
                            $errorString .= $error . "<br/>";
                        }
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = $errorString;
                    }
                }
            }
        }
    }

    public function editAction() {

        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $agentMapper = new Application_Model_AgentMapper();
        $agent = $agentMapper->getAgentById($id);
        $dMapper = new Application_Model_DistributorMapper();
        $dis = $dMapper->getAllDistributors();
        $this->view->dis = $dis;

        $this->view->agent = $agent;

        if ($request->isPost()) {

            $request_type = $request->getParam("request_type");

            if ($request_type == "edit") {

                $name = $request->getParam("name");
                $phone = $request->getParam("phone");
                $email = $request->getParam("email");
                $address = $request->getParam("address");
                $distributor = $request->getParam("distributor_id");
                $comments = $request->getParam("comments");
                $password = $request->getParam("password");
                $username = $request->getParam("username");



                if (count($errors) == 0) {


                    $agent->__set("name", $name);
                    $agent->__set("phone", $phone);
                    $agent->__set("email", $email);
                    $agent->__set("address", $address);
                    $agent->__set("distributor_id", $distributor);
                    $agent->__set("comments", $comments);
                    $agent->__set("percent_comm", "5");
                    $agent->__set("password", $password);
                    $agent->__set("username", $username);
                    $agent->__set("timestamp", date("Y-m-d"));


                    if ($agentMapper->updateAgent($agent)) {
                        $this->redirect("/admin/agent/");
                        $this->view->hasMessage = true;
                        $this->view->messageType = "success";
                        $this->view->message = "Agent has been updated successfully";
                    } else {
                        $this->view->hasMessage = true;
                        $this->view->messageType = "danger";
                        $this->view->message = "Error while updating Agent";
                    }
                } else {
                    $errorString = "";
                    foreach ($errors as $error) {
                        $errorString .= $error . "<br/>";
                    }
                    $this->view->hasMessage = true;
                    $this->view->messageType = "danger";
                    $this->view->message = $errorString;
                }
            }
        }
    }

    public function viewAction() {
        $request = $this->getRequest();
        $id = $request->getParam("id");

        $errors = array();

        $agentMapper = new Application_Model_AgentMapper();
        $agent = $agentMapper->getAgentById($id);
      

        $this->view->agent = $agent;
    }

}
